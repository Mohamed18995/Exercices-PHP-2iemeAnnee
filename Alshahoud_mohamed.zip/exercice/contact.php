<?php 
 $contact = array(); 
$contact[] = array('Nom' => alshahoud, 'Prénom' => mohamed, 'Adresse' => quai de rome 99, 'Téléphone' => 0489470853, 'Email' => ay1665ay@gmail.com, 'Naissance' => 01-08-1995); 
?>